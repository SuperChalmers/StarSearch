# CS6310-A6
Repo for Team 68's A6 assignment

# Run the backend

`cd backend`

`java -jar starsearch-0.0.1-SNAPSHOT.jar`

# Run the frontend

`cd frontend`

`npm start`

Point your browser to localhost:3000


When loading a scenario file load your scenario file to `./backend/testScenarios` or use one of the existing files.

