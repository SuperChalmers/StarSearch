# Simulation

Start the Simulation front end

### `npm start`

Open [http://localhost:3000](http://localhost:3000) to view it in the browser.
