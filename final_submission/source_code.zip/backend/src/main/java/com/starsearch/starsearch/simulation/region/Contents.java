package com.starsearch.starsearch.simulation.region;

public enum Contents {
    SUN,
    STARS,
    EMPTY,
    BARRIER,
    UNKNOWN
}
