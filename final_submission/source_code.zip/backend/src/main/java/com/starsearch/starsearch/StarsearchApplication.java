package com.starsearch.starsearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StarsearchApplication {

    public static void main(String[] args) {
        SpringApplication.run(StarsearchApplication.class, args);
    }

}
