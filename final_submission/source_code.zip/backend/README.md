## Instructions

java -jar starsearch-0.0.1-SNAPSHOT.jar
